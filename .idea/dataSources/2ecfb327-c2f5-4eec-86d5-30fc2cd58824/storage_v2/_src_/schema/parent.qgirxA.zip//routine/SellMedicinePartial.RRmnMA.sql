create
    definer = mysql@localhost procedure SellMedicinePartial(IN medicine_id int, IN sell_quantity decimal(10, 2))
BEGIN
    DECLARE current_size DECIMAL(10,2);
    DECLARE full_size DECIMAL(10,2);
    DECLARE current_amount INT;
    START TRANSACTION;
    SELECT m_size, m_full_size, m_amount 
    INTO current_size, full_size, current_amount 
    FROM medicinesInfo 
    WHERE m_id = medicine_id 
    FOR UPDATE;
    IF current_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Not enough stock (initial check)';
    END IF;
    SET current_size = current_size - sell_quantity;
    IF current_size <= 0 THEN
        SET current_amount = current_amount - 1;
        SET current_size = full_size - ABS(current_size);
    END IF;
    IF current_amount < 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Not enough stock (post-calculation)';
    END IF;
    UPDATE medicinesInfo 
    SET m_amount = current_amount,
        m_size = CASE 
            WHEN current_amount > 0 THEN current_size 
            ELSE 0 
        END
    WHERE m_id = medicine_id;
    COMMIT;
END;

